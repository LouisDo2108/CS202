#include "fraction.h"

Fraction::Fraction() : numerator(0), denominator(1){};

Fraction::Fraction(const int n) : numerator(n), denominator(1){};

Fraction::Fraction(const int n, const int d)
{
    if (d == 0)
    {
        cout << "Denominator can't be 0" << endl;
        exit(0);
    }
    numerator = n;
    denominator = d;
    this->reduced();
}

Fraction::Fraction(const Fraction &rhs)
{
    numerator = rhs.numerator;
    denominator = rhs.denominator;
    this->reduced();
}

Fraction &Fraction::operator=(const Fraction &rhs)
{
    numerator = rhs.numerator;
    denominator = rhs.denominator;
    return *this;
}

Fraction Fraction::operator+(const Fraction &rhs)
{
    Fraction temp(numerator * rhs.denominator + denominator * rhs.numerator, denominator * rhs.denominator);
    temp.reduced();
    return temp;
}

Fraction Fraction::operator-(const Fraction &rhs)
{
    Fraction temp(numerator * rhs.denominator - denominator * rhs.numerator, denominator * rhs.denominator);
    temp.reduced();
    return temp;
}

Fraction Fraction::operator*(const Fraction &rhs)
{
    Fraction temp(numerator * rhs.numerator, denominator * rhs.denominator);
    temp.reduced();
    return temp;
}

Fraction Fraction::operator/(const Fraction &rhs)
{
    Fraction temp(numerator * rhs.denominator, denominator * rhs.numerator);
    return temp;
}

bool Fraction::operator==(const Fraction &rhs)
{
    return numerator * rhs.denominator == denominator * rhs.numerator;
}

bool Fraction::operator!=(const Fraction &rhs)
{
    return numerator * rhs.denominator != denominator * rhs.numerator;
}

bool Fraction::operator>=(const Fraction &rhs)
{
    return numerator * rhs.denominator >= denominator * rhs.numerator;
}

bool Fraction::operator>(const Fraction &rhs)
{
    return numerator * rhs.denominator > denominator * rhs.numerator;
}

bool Fraction::operator<=(const Fraction &rhs)
{
    return numerator * rhs.denominator <= denominator * rhs.numerator;
}

bool Fraction::operator<(const Fraction &rhs)
{
    return numerator * rhs.denominator < denominator * rhs.numerator;
}

Fraction &Fraction::operator+=(const Fraction &rhs)
{
    numerator = numerator * rhs.denominator + denominator * rhs.numerator;
    denominator *= rhs.numerator;
    return *this;
}

Fraction &Fraction::operator-=(const Fraction &rhs)
{
    numerator = numerator * rhs.denominator - denominator * rhs.numerator;
    denominator *= rhs.numerator;
    return *this;
}
Fraction &Fraction::operator*=(const Fraction &rhs)
{
    numerator *= rhs.numerator;
    denominator *= rhs.denominator;
    return *this;
}
Fraction &Fraction::operator/=(const Fraction &rhs)
{
    if (rhs.denominator == 0)
        exit(1);
    numerator *= rhs.denominator;
    denominator *= rhs.numerator;
    return *this;
}

Fraction Fraction::operator++(int)
{
    Fraction temp(*this);
    numerator += denominator;
    return temp;
}

Fraction &Fraction::operator++()
{
    numerator += denominator;
    return *this;
}

Fraction Fraction::operator--(int)
{
    Fraction temp(*this);
    numerator -= denominator;
    return temp;
}

Fraction &Fraction::operator--()
{
    numerator -= denominator;
    return *this;
}

ostream &operator<<(ostream &out, const Fraction rhs)
{
    out << rhs.numerator << "/" << rhs.denominator << " = " << (float)rhs.numerator / (float)rhs.denominator << endl;
    return out;
}

// Fraction operator+(int x, const Fraction &rhs)
// {
//     return rhs + x;
// }

// Fraction operator-(int x, const Fraction &rhs)
// {
//     return rhs - x;
// }

// Fraction operator*(int x, const Fraction &rhs)
// {
//     return rhs * x;
// }

// Fraction operator/(int x, const Fraction &rhs)
// {
//     if (x == 0)
//         exit(1);
//     return rhs / x;
// }

void Fraction::reduced()
{
    int gcd = __gcd(numerator, denominator);
    numerator /= gcd;
    denominator /= gcd;
    cout << "ENd of function" << endl;
}

void Fraction::output()
{
    return;
}