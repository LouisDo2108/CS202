#ifndef _Header_H_
#define _Header_H_

#include <iostream>
#include <algorithm>
#include <string>

using namespace std;

class Fraction
{
private:
    int numerator, denominator;

public:
    Fraction();
    Fraction(const int n);
    Fraction(const int n, const int d);
    Fraction(const Fraction &rhs);

    Fraction &operator=(const Fraction &rhs);
    Fraction operator+(const Fraction &rhs);
    Fraction operator-(const Fraction &rhs);
    Fraction operator*(const Fraction &rhs);
    Fraction operator/(const Fraction &rhs);

    bool operator==(const Fraction &rhs);
    bool operator!=(const Fraction &rhs);
    bool operator>=(const Fraction &rhs);
    bool operator>(const Fraction &rhs);
    bool operator<=(const Fraction &rhs);
    bool operator<(const Fraction &rhs);

    Fraction &operator+=(const Fraction &rhs);
    Fraction &operator-=(const Fraction &rhs);
    Fraction &operator*=(const Fraction &rhs);
    Fraction &operator/=(const Fraction &rhs);

    Fraction operator++(int);
    Fraction &operator++();

    Fraction operator--(int);
    Fraction &operator--();

    friend Fraction operator+(int x, const Fraction &rhs);
    friend Fraction operator-(int x, const Fraction &rhs);
    friend Fraction operator*(int x, const Fraction &rhs);
    friend Fraction operator/(int x, const Fraction &rhs);

    friend ostream &operator<<(ostream &out, const Fraction rhs);

    void reduced();

    void output();
};

Fraction operator+(const Fraction lhs, int rhs);
Fraction operator+(int rhs, const Fraction lhs);

#endif