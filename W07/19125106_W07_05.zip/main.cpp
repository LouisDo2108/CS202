#include "fraction.h"
#include <iostream>

using namespace std;

template <class T>
class MyVector
{
private:
    T *arr;
    int size;
    int capacity;

public:
    // empty array
    MyVector();
    // n zeros
    MyVector(int n);
    MyVector(T *a, int n);
    MyVector(const MyVector &v);
    ~MyVector();
    int getSize();
    T getItem(int index);
    void setItem(T value, int index);
    void add(T value);
    void addRange(T *a, int n);
    void clear();
    bool contains(T value);
    void toArray(T *inputArr, int &n);
    bool equals(const MyVector &v);
    int indexOf(T value);
    int lastIndexOf(T value);
    void insert(T value, int index);
    void remove(T value);
    void removeAt(int index);
    void reverse();
    string toString();
    void sortAsc();
    void sortDesc();

    void print();
};

template <class T>
MyVector<T>::MyVector() : arr(new T[10]{T(0)}), size(0), capacity(10){};

template <class T>
MyVector<T>::MyVector(int n) : arr(new T[n * 2]{T(0)}), size(n), capacity(n * 2){};

template <class T>
MyVector<T>::MyVector(T *a, int n) : arr(new T[n * 2]{T(0)}), size(n), capacity(n * 2)
{
    for (int i = 0; i < n; ++i)
    {
        arr[i] = a[i];
    }
};

template <class T>
MyVector<T>::MyVector(const MyVector &v)
{
    if (this == &v)
        return;

    arr = new T[0]{T(0)};
    size = v.size;
    capacity = v.capacity;

    for (int i = 0; i < size; ++i)
    {
        arr[i] = v[i];
    }
};

template <class T>
MyVector<T>::~MyVector()
{
    if (arr)
        delete[] arr;
};

template <class T>
int MyVector<T>::getSize()
{
    return size;
};

template <class T>
T MyVector<T>::getItem(int index)
{
    if (index < size && index >= 0)
        return arr[index];
    cout << "Index out of range, return trash value!" << endl;
    return arr[capacity - 1];
};

template <class T>
void MyVector<T>::setItem(T value, int index)
{
    if (index < size && index >= 0)
    {
        arr[index] = value;
    }
}

template <class T>
void MyVector<T>::add(T value)
{
    if (size >= (capacity - 1))
    {
        capacity *= 2;
        T *temp = new T[capacity];
        for (int i = 0; i < size; ++i)
        {
            temp[i] = arr[i];
        }
        delete[] arr;
        arr = temp;
    }

    arr[size] = value;
    ++size;
}

template <class T>
void MyVector<T>::print()
{
    if (size <= 0)
    {
        cout << "My vector is empty!" << endl;
        return;
    }

    for (int i = 0; i < size; ++i)
        cout << "arr[" << i << "]: " << arr[i] << endl;
}

template <class T>
void MyVector<T>::addRange(T *a, int n)
{
    if ((size + n) >= (capacity - 1))
    {
        capacity = (capacity + n) * 2;
        T *temp = new T[capacity]{T(0)};
        for (int i = 0; i < size; ++i)
        {
            temp[i] = arr[i];
        }
        delete[] arr;
        arr = temp;
    }

    for (int i = 0; i < n; ++i)
    {
        arr[size + i] = a[i];
    }
    size += n;
}

template <class T>
void MyVector<T>::clear()
{
    delete[] arr;
    arr = nullptr;
    size = 0;
    capacity = 10;
}

template <class T>
bool MyVector<T>::contains(T value)
{
    if (size <= 0)
        return false;
    for (int i = 0; i < size; ++i)
    {
        if (arr[i] == value)
        {
            return true;
        }
    }
    return false;
}

template <class T>
void MyVector<T>::toArray(T *inputArr, int &n)
{
    if (!inputArr)
    {
        cout << "The give array is null" << endl;
        return;
    }
    for (int i = 0; i < n; ++i)
    {
        if (i >= size)
            inputArr[i] = T(0);
        else
            inputArr[i] = this->arr[i];
    }
}

template <class T>
bool MyVector<T>::equals(const MyVector &v)
{
    if (this == &v)
        return true;
    if (size == v.size)
    {
        for (int i = 0; i < size; ++i)
        {
            if (v.arr[i] != arr[i])
                return false;
        }
    }
    return true;
}

template <class T>
int MyVector<T>::indexOf(T value)
{
    if (size <= 0)
        return -1;

    for (int i = 0; i < size; ++i)
    {
        if (arr[i] == value)
            return i;
    }

    cout << "Couldn't fidn the index of the give value" << endl;
    return -1;
}

int main()
{
    const int size = 10;
    MyVector<Fraction> vec;

    int i = 0;
    for (i = 0; i < size; ++i)
    {
        vec.add(Fraction(i, i + 1));
    }
    vec.print();

    Fraction *extra = new Fraction[5];
    for (i; i < size + 5; ++i)
    {
        extra[i - size] = Fraction(i, i + 1);
    }
    vec.addRange(extra, 5);
    vec.print();

    cout << "Size: " << vec.getSize() << endl;
    Fraction got = vec.getItem(0);
    cout << got;
    vec.setItem(Fraction(100, 3), 0);
    got = vec.getItem(0);
    cout << got;

    int reSize = 10;
    Fraction *returnArr = new Fraction[reSize];

    vec.toArray(returnArr, reSize);
    cout << "toArray: " << endl;
    for (i = 0; i < reSize; ++i)
    {
        cout << returnArr[i];
    }

    cout << vec.indexOf(Fraction(100, 3)) << endl;
    vec.clear();
    delete[] returnArr;
    delete[] extra;
    return 0;
}