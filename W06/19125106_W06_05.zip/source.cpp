#include "header.h"

string trueOrFalse(bool tf)
{
    if (tf)
        return "True";
    return "False";
}

//CItem
CItem::CItem() : name(""), size(0), roAttr(0), hiAttr(0){};

CItem::CItem(string name) : name(name), size(0), roAttr(0), hiAttr(0){};

CItem::CItem(string name, int s) : name(name), size(s), roAttr(0), hiAttr(0){};

void CItem::print()
{
    cout << "Name: " << name << endl;
    cout << "Size: " << size << endl;
    cout << "Read only attributes: " << roAttr << endl;
    cout << "Hidden attributes: " << hiAttr << endl;
    cout << endl;
}

int CItem::getSize()
{
    return size;
}

string CItem::getName()
{
    return name;
}

bool CItem::getHi()
{
    return hiAttr;
}

//Folder

CFolder::CFolder(string name) //Constructor
    : CItem(name), numFiles(0), numFolders(0){};

void CFolder::add(CFile *rhs) //add a file
{
    ++numFiles;
    this->size += rhs->getSize();
    content.push_back(rhs);
}

void CFolder::add(CFolder *rhs)
{
    ++numFolders;
    this->size += rhs->getSize();
    content.push_back(rhs);
}

void CFolder::print(bool printHidden)
{
    cout << "Folder's info: " << endl;
    CItem::print();
    cout << "Number of files: " << numFiles << endl;
    cout << "Number of folders: " << numFolders << endl;
    for (int i = 0; i < content.size(); ++i)
    {
        if (printHidden && content[i]->getHi())
            content[i]->print();
        if (!printHidden)
            content[i]->print();
    }
}

int CFolder::getNumFiles()
{
    return numFiles;
}

int CFolder::getNumFolders()
{
    return numFolders;
}

//File
CFile::CFile(string name, int s)
    : CItem(name, s){};

void CFile::print()
{
    cout << "File's info:" << endl;
    CItem::print();
}