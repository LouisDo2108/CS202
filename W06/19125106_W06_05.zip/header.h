#ifndef header
#define header

#include <iostream>
#include <string>
#include <vector>

using namespace std;

string trueOrFalse(bool tf);

class CItem
{
public:
    CItem();
    CItem(string name);
    CItem(string name, int s);
    virtual void print();
    int getSize();
    string getName();
    bool getHi();

protected:
    string name;
    int size;
    bool roAttr;
    bool hiAttr;
};

class CFile : public CItem
{
public:
    CFile(string name, int s);
    void print();
};

class CFolder : public CItem
{
public:
    CFolder(string name);
    void add(CFile *rhs);
    void add(CFolder *rhs);
    void print(bool printHidden);
    int getNumFolders();
    int getNumFiles();

private:
    int numFiles;
    int numFolders;
    vector<CItem *> content;
};
#endif