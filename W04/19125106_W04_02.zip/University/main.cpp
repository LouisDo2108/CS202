#include "header.h"

int main()
{
    Teacher a;
    Homeroom b;

    a.input();
    b.input();

    a.output();
    b.output();

    return 0;
}