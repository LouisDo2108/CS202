#include "header.h"
#include "date.h"

int main()
{
    ProEmp a;
    dayEmp b;

    a.input();
    b.input();

    a.output();
    b.output();
    
    return 0;
}